# Secret Santa Picker
Backend server with file persistence.
Deploy on Render and configure SMTP + ADMIN_KEY.
