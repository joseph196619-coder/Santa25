// server.js - Secret Santa Picker (full working version with file persistence)
const express = require('express');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');

const DATA_FILE = path.join(__dirname, 'data.json');

function loadData(){
  if(!fs.existsSync(DATA_FILE)){
    const init = { staff: [], numbers: [], assignments: {} };
    fs.writeFileSync(DATA_FILE, JSON.stringify(init, null, 2));
  }
  return JSON.parse(fs.readFileSync(DATA_FILE));
}
function saveData(d){ fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2)); }

function createTransporter(){
  if(!process.env.SMTP_HOST) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: (process.env.SMTP_SECURE === 'true'),
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
}

const app = express();
app.use(cors());
app.use(bodyParser.json());

// simple admin auth using ADMIN_KEY env var
function requireAdmin(req, res, next){
  const key = req.headers['x-admin-key'] || req.query.admin_key;
  if(!process.env.ADMIN_KEY) return res.status(500).json({ error: 'ADMIN_KEY not set on server' });
  if(!key || key !== process.env.ADMIN_KEY) return res.status(401).json({ error: 'unauthorized' });
  next();
}

// Admin: upload staff list [{name,email}, ...]
app.post('/api/admin/upload', requireAdmin, (req, res) => {
  const staff = req.body.staff;
  if(!Array.isArray(staff) || staff.length === 0) return res.status(400).json({ error: 'invalid staff' });
  const data = loadData();
  data.staff = staff.map((s,i) => ({ id: i+1, name: s.name, email: s.email }));
  // create shuffled numbers mapping
  const numbers = data.staff.map(s => s.id);
  for(let i = numbers.length-1; i>0; i--){
    const j = Math.floor(Math.random()*(i+1));
    [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
  }
  data.numbers = numbers;
  data.assignments = {};
  saveData(data);
  res.json({ ok: true, count: data.staff.length });
});

// Public: list numbers and if taken
app.get('/api/numbers', (req, res) => {
  const data = loadData();
  const out = data.numbers.map((mapped, idx) => ({ number: idx+1, taken: !!data.assignments[idx+1] }));
  res.json({ numbers: out, count: out.length });
});

// Public: pick a number
app.post('/api/pick', async (req, res) => {
  try {
    const { pickerName, pickerEmail, number } = req.body;
    if(!pickerEmail || !number) return res.status(400).json({ error: 'pickerEmail and number required' });
    const data = loadData();
    const total = data.numbers.length;
    if(number < 1 || number > total) return res.status(400).json({ error: 'invalid number' });
    if(data.assignments[number]) return res.status(400).json({ error: 'number already taken' });

    const mappedStaffId = data.numbers[number-1];
    const picked = data.staff.find(s => s.id === mappedStaffId);
    if(!picked) return res.status(500).json({ error: 'mapping error' });

    data.assignments[number] = {
      pickerName: pickerName || pickerEmail,
      pickerEmail,
      pickedStaffId: picked.id,
      pickedStaffName: picked.name,
      pickedStaffEmail: picked.email,
      pickedAt: new Date().toISOString()
    };
    saveData(data);

    const transporter = createTransporter();
    const revealText = `You picked number ${number}. The person is: ${picked.name} (${picked.email}).`;

    if(!transporter){
      return res.json({ ok: true, reveal: picked.name, note: 'No SMTP configured' });
    }

    const mailOptions = {
      from: process.env.EMAIL_FROM || process.env.SMTP_USER,
      to: pickerEmail,
      subject: process.env.EMAIL_SUBJECT || 'Your Secret Santa pick 🎁',
      text: `Hi ${pickerName || ''},

${revealText}

Keep it secret!`
    };

    await transporter.sendMail(mailOptions);
    res.json({ ok: true, message: 'Picked and email sent' });
  } catch(err){
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// Admin: view assignments
app.get('/api/admin/assignments', requireAdmin, (req, res) => {
  const data = loadData();
  res.json({ assignments: data.assignments, staff: data.staff });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
